/**
 * Created by bianca on 12/2/2017.
 */
public interface IFactory {
    /**
     *
     * @return o instanta SubjectF
     */
    public SubjectF create();
}
